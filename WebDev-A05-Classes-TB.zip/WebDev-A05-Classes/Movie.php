<?php

/**
 * 
 * @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 * APA Citation: PHP Documentation Group. (n.d.). Classes and Objects. PHP Manual. https://www.php.net/manual/en/language.oop5.php
 */

declare(strict_types=1);

class Movie
{
    private int $id;
    private string $title;
    private int $year;
    private string $genre;
    private string $director;
    private string $mainActor;
    private string $picture;
    private string $imdb;

    public function __construct(array $data, int $id)
    {
        $this->id        = $id;
        $this->title     = $data['title']     ?? '';
        $this->year      = (int)($data['year'] ?? 0);
        $this->genre     = $data['genre']     ?? '';
        $this->director  = $data['director']  ?? '';
        $this->mainActor = $data['main_actor'] ?? '';
        $this->picture   = $data['picture']   ?? '';
        $this->imdb      = $data['imdb']      ?? '';
    }

    // Getters
    public function getTitle(): string    { return $this->title; }
    public function getYear(): int        { return $this->year; }
    public function getGenre(): string    { return $this->genre; }
    public function getDirector(): string { return $this->director; }
    public function getMainActor(): string { return $this->mainActor; }
    public function getPicture(): string  { return $this->picture; }
    public function getImdb(): string     { return $this->imdb; }

    public function toTableCell(): string
    {
        return sprintf(
            '<td style="text-align:center;padding:15px;vertical-align:top;">
                <img src="%s" alt="%s" width="150" loading="lazy"><br>
                <strong>%s</strong> (%d)<br>
                <em>%s</em><br>%s
             </td>',
            htmlspecialchars($this->picture),
            htmlspecialchars($this->title),
            htmlspecialchars($this->title),
            $this->year,
            htmlspecialchars($this->director),
            htmlspecialchars($this->genre)
        );
    }
}