<!DOCTYPE html>

<?php
/**

 * Login Page
 * Renders a simple HTML login form that posts username/password to authenticate.php.
 *
 * Notes:
 *  - This file is presentation-only; authentication and session handling belong in authenticate.php.
 *  - Avoid placing sensitive logic or credentials in this file.
 *
 * References (APA):
 *  PHP Group. (n.d.). HTML Forms. PHP Manual. https://www.php.net/manual/en/tutorial.forms.php
 *  PHP Group. (n.d.). PHP Manual. https://www.php.net/
 *
 * @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 */
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>body{font-family:Arial;padding:40px;} input{padding:8px;margin:5px;}</style>
</head>
<body>
    <h2>Login</h2>
    <form method="post" action="authenticate.php">
        <label>Username: <input type="text" name="username" required></label><br>
        <label>Password: <input type="password" name="password" required></label><br><br>
        <button type="submit">Login</button>
    </form>
</body>
</html>