<?php

/**
 * @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 * Authenticate user credentials and create session
 * APA Citation: PHP Documentation Group. (n.d.). session_start. PHP Manual. https://www.php.net/manual/en/function.session-start.php
 * APA Citation: PHP Documentation Group. (n.d.). PDO. PHP Manual. https://
 * www.php.net/manual/en/book.pdo.php
 * APA Citation: PHP Documentation Group. (n.d.). password_verify. PHP Manual. https
 * ://www.php.net/manual/en/function.password-verify.php
 * APA Citation: PHP Documentation Group. (n.d.). bin2hex. PHP Manual.
 * https://www.php.net/manual/en/function.bin2hex.php
 * APA Citation: PHP Documentation Group. (n.d.). random_bytes. PHP Manual.
 * https://www.php.net/manual/en/function.random-bytes.php
 * Usage: Processes login form submission; validates credentials against DB
 * Security: Uses prepared statements; verifies hashed passwords; creates secure session
 * Features: On success, creates session record in DB and redirects to admin.php
 * On failure, redirects back to login.php
 
 */

declare(strict_types=1);
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {// Only accept POST requests
    header('Location: login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->prepare("SELECT user_id, password FROM users WHERE username = ? LIMIT 1");
$stmt->execute([$username]);
$user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {
    // Valid login
    $userId = (int)$user['user_id'];
    $sessionId = bin2hex(random_bytes(32));

    $_SESSION['user_id']    = $userId;
    $_SESSION['session_id'] = $sessionId;

    $now = time();
    $stmt = $pdo->prepare(
        "INSERT INTO login_sessions (user_id, session_id, last_access_time) 
         VALUES (?, ?, ?)"
    );
    $stmt->execute([$userId, $sessionId, $now]);

    header('Location: admin.php');
    exit;
}

// Invalid credentials
header('Location: login.php');
exit;