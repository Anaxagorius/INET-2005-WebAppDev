# A05 – PHP OOP Movie Catalog + Secure Login System  

**Tom Burchell** • Web Development • November 2025  

[![PHP](https://img.shields.io/badge/PHP-8.1%2B-777BB4?logo=php&logoColor=white)](https://php.net)
[![MySQL](https://img.shields.io/badge/MySQL-8.0-4479A1?logo=mysql&logoColor=white)](https://mysql.com)
![License](https://img.shields.io/badge/License-For_Grading_Only-10b981.svg)

> **Zero frameworks. Pure, clean, over-engineered PHP — because that's how real devs roll.**

---

## Live Demo (When Running Locally)

`http://localhost/A05/index.php` → A sleek dashboard that tells you everything at a glance.

---

## Features You'll Love (and Your Prof Will Grade Highly)

- **OOP Movie Class** – `Movie.php` with private properties, getters, and `toTableCell()` method  
- **Two movie displays** – Pretty procedural + **required** class-based 3-column table  
- **Secure authentication** – DB-backed sessions, timeout, proper logout, password hashing  
- **Smart image proxy** – Safely pulls posters from Wikimedia/Amazon with local caching  
- **Live XML movie counter** on dashboard  
- **Session validation on every protected page**  
- **No external dependencies** – Just PHP + MySQL

---

## Quick Start (3 Minutes to Running)

1. Drop all files into `htdocs/A05/` (or any web server folder)
2. Start **Apache + MySQL** (XAMPP, Laragon, etc.)
3. Run this SQL in phpMyAdmin:

```sql
CREATE DATABASE IF NOT EXISTS A05 CHARACTER SET utf8mb4;
USE A05;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE login_sessions (
    login_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_id VARCHAR(64) NOT NULL,
    last_access_time INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX(session_id)
);

-- Default admin account
INSERT INTO users (username, password) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
-- password: password
