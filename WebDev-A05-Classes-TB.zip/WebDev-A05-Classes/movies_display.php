<?php

 /**@author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 * APA Citation: PHP Documentation Group. (n.d.). SimpleXML. PHP Manual. https://www.php.net/manual/en/book.simplexml.php
*/

require_once 'Movie.php';

$xml = simplexml_load_file('fav_movies.xml');
if (!$xml) die('XML failed to load');

$movies = [];
foreach ($xml->movie as $i => $node) {
    $data = (array)$node;
    $data = $data['@attributes'] ?? $data; // SimpleXML quirk
    $movies[] = new Movie($data, $i + 1);
}
?>
<!DOCTYPE html>
<html><head><title>Movies – Class Version (A05 Part 1)</title></head><body>
<h1>Movie Catalog – OOP Version (3 per row)</h1>
<table><tr>
<?php foreach ($movies as $i => $movie): ?>
    <?= $movie->toTableCell() ?>
    <?php if (($i + 1) % 3 === 0 && $i !== count($movies)-1): ?></tr><tr><?php endif; ?>
<?php endforeach; ?>
<?php while (($i + 1) % 3 !== 0): $i++; ?><td></td><?php endwhile; ?>
</tr></table>
</body></html>
