<?php

 /** @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 
*/

session_start();
require_once 'config.php';

if (isset($_SESSION['user_id'], $_SESSION['session_id'])) {
    $stmt = $pdo->prepare(
        "DELETE FROM login_sessions WHERE user_id = ? AND session_id = ?"
    );
    $stmt->execute([$_SESSION['user_id'], $_SESSION['session_id']]);
}

session_unset();
session_destroy();
header('Location: login.php');
exit;