<?php

/**
 * @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 * Admin area with session validation
 * APA Citation: PHP Documentation Group. (n.d.). session_start. PHP Manual. https://www.php.net/manual/en/function.session-start.php
 * APA Citation: PHP Documentation Group. (n.d.). PDO. PHP Manual. https://www.php.net/manual/en/book.pdo.php
 * APA Citation: PHP Documentation Group. (n.d.). PDOStatement::execute. PHP Manual. https://www.php.net/manual/en/pdostatement.execute.php
 * APA Citation: PHP Documentation Group. (n.d.). htmlspecialchars. PHP Manual. https://www.php.net/manual/en/function.htmlspecialchars.php
 * Usage: Accessed only by logged-in users with valid sessions
 * Security: Validates session against DB; redirects to login if invalid
 * Features: Displays welcome message with username; logout link
 */

declare(strict_types=1);
session_start();
require_once 'config.php';

$userId    = $_SESSION['user_id'] ?? null;
$sessionId = $_SESSION['session_id'] ?? null;

if (!$userId || !$sessionId) {
    header('Location: login.php');
    exit;
}

$now = time();
$stmt = $pdo->prepare(
    "SELECT login_id FROM login_sessions 
     WHERE user_id = ? AND session_id = ? AND last_access_time > ? 
     LIMIT 1"
);
$stmt->execute([$userId, $sessionId, $now - 1800]); // 30-minute timeout example

$sessionRow = $stmt->fetch();

if (!$sessionRow) {
    // Invalid or expired session
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}

// Update last access time
$pdo->prepare(
    "UPDATE login_sessions SET last_access_time = ? 
     WHERE user_id = ? AND session_id = ?"
)->execute([$now, $userId, $sessionId]);

// Fetch username for welcome message
$stmt = $pdo->prepare("SELECT username FROM users WHERE user_id = ?");
$stmt->execute([$userId]);
$username = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Area</title>
    <style>body{font-family:Arial;padding:40px;background:#f4f4f4;}</style>
</head>
<body>
    <h1>Welcome, <?= htmlspecialchars((string)$username) ?>!</h1>
    <p>You are successfully logged in.</p>
    <p><a href="logout.php">Logout</a></p>
</body>
</html>