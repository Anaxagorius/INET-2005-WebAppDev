<?php
/*
 
 * @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 * index.php - Assignment 05 Dashboard
 * Features:
 *  • Live movie count from fav_movies.xml
 *  • Secure login system status (checks A05 DB + active session)
 *  • Direct links to both movie displays (procedural + required OOP version)
 * 
 * APA Citation: PHP Group. (n.d.). PHP Manual. PHP.net. https://www.php.net/manual/en/
 * APA Citation: World Wide Web Consortium. (2014). HTML5. W3C Recommendation. https://www.w3.org/TR/html5/
 * 
 */

declare(strict_types=1);

// --- Movie count (from XML) ---
$movieCount = 'N/A';
if (file_exists('fav_movies.xml')) {
    $xml = simplexml_load_file('fav_movies.xml');
    $movieCount = $xml ? count($xml->movie) : 'Error loading XML';
}

// --- Login system status ---
session_start();
$loginStatus = 'Not logged in';
$username = 'Guest';

if (isset($_SESSION['user_id'], $_SESSION['session_id'])) {
    // Quick validation – check if session still valid in DB
    try {
        $pdo = new PDO('mysql:host=localhost;dbname=A05;charset=utf8mb4', 'root', '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_SILENT
        ]);
        $stmt = $pdo->prepare("
            SELECT u.username 
            FROM login_sessions ls 
            JOIN users u ON ls.user_id = u.user_id 
            WHERE ls.user_id = ? AND ls.session_id = ? AND ls.last_access_time > ?
            LIMIT 1
        ");
        $stmt->execute([$_SESSION['user_id'], $_SESSION['session_id'], time() - 1800]);
        if ($row = $stmt->fetch()) {
            $username = htmlspecialchars($row['username'], ENT_QUOTES, 'UTF-8');
            $loginStatus = "Logged in as <strong>$username</strong>";
        }
    } catch (Exception $e) {
        
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A05 – Movie Class & Secure Login System</title>
    <style>
        :root { --primary: #007bff; --success: #28a745; --dark: #212529; --light: #f8f9fa; }
        * { box-sizing: border-box; margin:0; padding:0; }
        body { font-family: system-ui, -apple-system, sans-serif; background: var(--light); color: #333; line-height: 1.6; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); overflow: hidden; }
        header { background: linear-gradient(135deg, #007bff, #0056b3); color: white; padding: 30px; text-align: center; }
        h1 { font-size: 2rem; margin: 0; }
        .subtitle { opacity: 0.9; font-weight: normal; margin-top: 8px; }
        .stats { padding: 20px; background: #f1f3f5; text-align: center; font-size: 1.1rem; }
        .stats span { font-weight: 600; color: var(--primary); }
        nav { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; padding: 30px; }
        .card { background: #fff; border: 1px solid #e9ecef; border-radius: 8px; padding: 20px; transition: transform 0.2s, box-shadow 0.2s; }
        .card:hover { transform: translateY(-4px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
        .card h3 { color: var(--primary); margin-bottom: 10px; border-bottom: 2px solid var(--primary); padding-bottom: 8px; }
        .card p { font-size: 0.95rem; color: #555; margin: 12px 0; }
        .card a { display: inline-block; background: var(--primary); color: white; padding: 10px 16px; border-radius: 6px; text-decoration: none; font-weight: 500; transition: background 0.2s; }
        .card a:hover { background: #0056b3; }
        .card .done { background: var(--success); cursor: default; }
        .card .done:hover { background: #218838; }
        .login-info { text-align: center; padding: 15px; background: #d4edda; color: #155724; font-weight: 500; }
        footer { text-align: center; padding: 20px; background: #343a40; color: #adb5bd; font-size: 0.9rem; }
        @media (max-width: 600px) { nav { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Assignment 05 – Complete</h1>
            <p class="subtitle">OOP Movie Class • Secure Session-Based Authentication</p>
        </header>

        <div class="stats">
            Movies in catalog: <span><?= $movieCount ?></span> 
            • Authentication status: <span><?= $loginStatus ?></span>
        </div>

        <?php if ($loginStatus !== 'Not logged in'): ?>
            <div class="login-info">
                Welcome back, <?= $username ?>! | <a href="logout.php" style="color:#155724; text-decoration:underline;">Logout</a>
            </div>
        <?php endif; ?>

        <nav>
            <div class="card">
                <h3>Generate Movies XML</h3>
                <p>Creates fav_movies.xml with 10 real movies (posters included).</p>
                <?php if (file_exists('fav_movies.xml')): ?>
                    <a href="#" class="done" onclick="alert('XML already exists!')">Already Generated</a>
                <?php else: ?>
                    <a href="create_movies.php">Run Generator</a>
                <?php endif; ?>
            </div>

            <div class="card">
                <h3>Movies Table (Pretty Version)</h3>
                <p>Procedural display with posters, IMDB links, and clean layout.</p>
                <a href="display_movies.php">View Pretty Table</a>
            </div>

            <div class="card">
                <h3>Movies Table (Required OOP)</h3>
                <p>Uses Movie class + foreach → array → 3-column HTML table.</p>
                <a href="movies_display.php">View Class-Based Table</a>
            </div>

            <div class="card">
                <h3>Admin Login System</h3>
                <p>Secure login with session tracking, timeout, and DB validation.</p>
                <?php if ($loginStatus === 'Not logged in'): ?>
                    <a href="login.php">Login →</a>
                <?php else: ?>
                    <a href="admin.php">Go to Admin Panel</  <a href="admin.php">Go to Admin Panel</a>
                <?php endif; ?>
            </div>
        </nav>

        <footer>
            <p>Assignment 05 • PHP OOP + Secure Authentication • Built with best practices • Zero framework bloat</p>
        </footer>
    </div>
</body>
</html>