<?php

/**
 * 
 * @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 * 
 */

declare(strict_types=1);

const DB_HOST = 'localhost';
const DB_NAME = 'A05';
const DB_USER = 'root'; //Default user for XAMPP     
const DB_PASS = '';          

try {// Create a new PDO instance
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());// Handle connection error
}