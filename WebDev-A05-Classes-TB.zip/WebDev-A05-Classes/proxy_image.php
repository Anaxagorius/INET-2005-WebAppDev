<?php
 /** @author  Tom Burchell
 * @package WebDev-A05-Classes
 * @since   2025-11-26
 * APA Citation: PHP Documentation Group. (n.d.). file_get_contents. PHP Manual. https://www.php.net/manual/en/function.file-get-contents.php
 * APA Citation: PHP Documentation Group. (n.d.). stream_context_create. PHP Manual.
 * https://www.php.net/manual/en/function.stream-context-create.php
 */

 // Config 
$allowed_domains = ['m.media-amazon.com', 'www.imdb.com']; // Whitelist IMDB sources
$max_size = 5 * 1024 * 1024; // 5MB limit
$cache_dir = __DIR__ . '/cache/'; // Local cache
$default_ttl = 3600; // 1 hour cache

// Input validation
$url = filter_input(INPUT_GET, 'url', FILTER_VALIDATE_URL);
$ttl = (int) filter_input(INPUT_GET, 'cache', FILTER_VALIDATE_INT, ['options' => ['default' => $default_ttl, 'min_range' => 60, 'max_range' => 86400]]);

// Early exit on invalid/missing URL
if (!$url) {
    http_response_code(400);
    echo 'Invalid or missing URL parameter.';
    exit;
}

// Security: Check domain whitelist
$parsed_url = parse_url($url);
if (!in_array($parsed_url['host'] ?? '', $allowed_domains, true)) {
    http_response_code(403);
    echo 'URL not allowed.';
    exit;
}

// Cache logic - Check if fresh cache exists
$cache_file = $cache_dir . md5($url) . '.jpg'; // Assume JPG; extend for PNG/etc.
$cache_ttl = $ttl; // Use query param or default

if (is_dir($cache_dir) && file_exists($cache_file) && (time() - filemtime($cache_file)) < $cache_ttl) {
    // Serve from cache
    header('Content-Type: image/jpeg');
    header('Content-Length: ' . filesize($cache_file));
    readfile($cache_file);
    exit;
}

// Fetch and cache if miss
$context = stream_context_create(['http' => ['timeout' => 10]]); // 10s timeout
$image_data = @file_get_contents($url, false, $context);

if ($image_data === false || strlen($image_data) > $max_size) {
    http_response_code(404);
    echo 'Image fetch failed or too large.';
    exit;
}

// Cache it (create dir if needed)
if (!is_dir($cache_dir)) {
    mkdir($cache_dir, 0755, true);
}
file_put_contents($cache_file, $image_data);

// Stream response - Optimized: No memory buffering
header('Content-Type: image/jpeg'); // Adjust based on extension if needed
header('Cache-Control: public, max-age=' . $cache_ttl);
echo $image_data;

//APA Citation: PHP Documentation Group. (n.d.). file_get_contents. PHP Manual. https://www.php.net/manual/en/function.file-get-contents.php
//APA Citation: PHP Documentation Group. (n.d.). stream_context_create. PHP Manual.
// https://www.php.net/manual/en/function.stream-context-create.php
?>